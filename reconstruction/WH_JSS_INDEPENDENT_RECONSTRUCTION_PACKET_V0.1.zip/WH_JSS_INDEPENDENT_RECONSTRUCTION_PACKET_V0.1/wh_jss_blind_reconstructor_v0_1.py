from __future__ import annotations
import json, hashlib
from copy import deepcopy

TOPOLOGIES = [
    'SINGLE_SOURCE_LOCAL','MULTI_SOURCE','EQUIFINALITY','CUMULATIVE_PATH','COMPENSATED_OR_MASKED'
]

def tri(v):
    if v is True: return 'TRUE'
    if v is False: return 'FALSE'
    return 'UNKNOWN'

def compat(required, disqualifiers=()):
    if 'FALSE' in required or 'TRUE' in disqualifiers:
        return 'INCOMPATIBLE'
    if 'UNKNOWN' in required or 'UNKNOWN' in disqualifiers:
        return 'UNRESOLVED'
    return 'COMPATIBLE'

def topology_compatibility(c):
    df = c.get('direct_failures', None)
    n_direct = None if df is None else len(df)
    mss = c.get('minimal_source_sets', None)
    n_sets = None if mss is None else len(mss)
    return {
        'SINGLE_SOURCE_LOCAL': compat([
            'UNKNOWN' if n_direct is None else ('TRUE' if n_direct == 1 else 'FALSE'),
            tri(c.get('single_source_reachable')),
        ]),
        'MULTI_SOURCE': compat([
            'UNKNOWN' if n_direct is None else ('TRUE' if n_direct >= 2 else 'FALSE'),
            tri(c.get('multi_source_reachable')),
        ]),
        'EQUIFINALITY': compat([
            'UNKNOWN' if n_sets is None else ('TRUE' if n_sets >= 2 else 'FALSE')
        ]),
        'CUMULATIVE_PATH': compat([
            tri(c.get('local_contracts_all_pass')),
            tri(c.get('path_or_global_invariant_fail')),
            'UNKNOWN' if n_direct is None else ('TRUE' if n_direct == 0 else 'FALSE'),
        ]),
        'COMPENSATED_OR_MASKED': compat([
            tri(c.get('upstream_or_path_abnormality')),
            tri(c.get('endpoint_acceptable')),
            tri(c.get('opposing_influence')),
        ]),
    }

def reconstruct(c):
    out = {
        'case_id': c['case_id'],
        'diagnostic_disposition': 'UNDERDETERMINED',
        'topology_label': None,
        'known_space_compatible': False,
        'resolution_state': 'UNDERDETERMINED',
        'compatible_topologies': [],
        'unresolved_topologies': [],
        'exact_localization': None,
        'candidate_source_sets': [],
        'inspection_state': 'NOT_REQUESTED',
        'repair_recommendation_entitled': False,
        'repair_target': None,
        'repair_execution_authorized': False,
        'closure_state': 'NOT_APPLICABLE',
        'registry_promotion_state': 'NOT_APPLICABLE',
        'reason_codes': [],
    }
    # 1. representation/integrity precedence
    if c.get('integrity_contradiction', False):
        out['diagnostic_disposition'] = 'HOLD_REPRESENTATION'
        out['resolution_state'] = 'HOLD_REPRESENTATION'
        out['reason_codes'].append('INTEGRITY_PRECEDENCE')
        return finish_governance(c, out)

    # 2. detection sufficiency
    ds = c.get('detection_status','UNKNOWN')
    if ds == 'UNKNOWN':
        out['diagnostic_disposition'] = 'UNDERDETERMINED'
        out['resolution_state'] = 'UNDERDETERMINED'
        out['reason_codes'].append('DETECTION_INSUFFICIENT')
        return finish_governance(c, out)
    if ds == 'CLEAN':
        out['diagnostic_disposition'] = 'CLEAN'
        out['resolution_state'] = 'CLEAN'
        out['reason_codes'].append('CLEAN_PREDICATES_SATISFIED')
        return finish_governance(c, out)

    # 3. after abnormality is established, construct/retain Z source sets
    out['candidate_source_sets'] = deepcopy(c.get('minimal_source_sets') or [])
    if c.get('minimal_source_sets') is not None and len(c['minimal_source_sets']) == 1:
        out['exact_localization'] = list(c['minimal_source_sets'][0])

    # 4. topology sufficiency / inspection branch
    if not c.get('topology_fields_complete', False):
        out['diagnostic_disposition'] = 'UNDERDETERMINED'
        if c.get('inspection_eligible', False):
            out['resolution_state'] = 'HOLD_TARGETED_INSPECTION'
            out['inspection_state'] = 'REQUEST_ELIGIBLE'
            out['reason_codes'].append('TOPOLOGY_INSUFFICIENT_INSPECTION_AVAILABLE')
        else:
            out['resolution_state'] = 'UNDERDETERMINED'
            out['reason_codes'].append('TOPOLOGY_INSUFFICIENT')
        return finish_governance(c, out)

    # 5. known topology compatibility and primitive decomposition
    cm = topology_compatibility(c)
    out['compatible_topologies'] = sorted([t for t,s in cm.items() if s == 'COMPATIBLE'])
    out['unresolved_topologies'] = sorted([t for t,s in cm.items() if s == 'UNRESOLVED'])
    out['known_space_compatible'] = len(out['compatible_topologies']) > 0

    ncomp = len(out['compatible_topologies'])
    if ncomp == 1:
        t = out['compatible_topologies'][0]
        out['diagnostic_disposition'] = f'KNOWN_CLASS({t})'
        out['topology_label'] = t
        if t == 'EQUIFINALITY' and len(out['candidate_source_sets']) >= 2:
            if c.get('inspection_eligible', False):
                out['resolution_state'] = 'HOLD_TARGETED_INSPECTION'
                out['inspection_state'] = 'REQUEST_ELIGIBLE'
                out['reason_codes'].append('TOPOLOGY_KNOWN_SOURCE_UNRESOLVED')
            else:
                out['resolution_state'] = 'RESOLVED_TOPOLOGY_SOURCE_UNRESOLVED'
                out['reason_codes'].append('EQUIFINALITY_NO_EXACT_SOURCE')
        else:
            out['resolution_state'] = 'RESOLVED_DIAGNOSTIC'
            out['reason_codes'].append('UNIQUE_KNOWN_TOPOLOGY')
    elif c.get('known_primitive_decomposable', False):
        out['diagnostic_disposition'] = 'KNOWN_PRIMITIVE_COMBINATION'
        out['resolution_state'] = 'RESOLVED_DIAGNOSTIC'
        out['reason_codes'].append('KNOWN_PRIMITIVE_DECOMPOSITION')
    elif ncomp > 1:
        out['diagnostic_disposition'] = 'UNDERDETERMINED'
        if c.get('inspection_eligible', False):
            out['resolution_state'] = 'HOLD_TARGETED_INSPECTION'
            out['inspection_state'] = 'REQUEST_ELIGIBLE'
            out['reason_codes'].append('MULTIPLE_COMPATIBLE_TOPOLOGIES')
        else:
            out['resolution_state'] = 'UNDERDETERMINED'
            out['reason_codes'].append('MULTIPLE_COMPATIBLE_NO_DISCRIMINATOR')
    elif c.get('structural_residual', False):
        out['diagnostic_disposition'] = 'NEW_TOPOLOGY_CANDIDATE'
        out['resolution_state'] = 'CANDIDATE_ONLY'
        out['reason_codes'].append('NO_KNOWN_COMPATIBLE_WITH_STRUCTURAL_RESIDUAL')
    else:
        out['diagnostic_disposition'] = 'UNDERDETERMINED'
        out['resolution_state'] = 'UNDERDETERMINED'
        out['reason_codes'].append('NO_UNIQUE_ENTITLED_TOPOLOGY')

    if c.get('minimal_source_sets') is None or len(c.get('minimal_source_sets') or []) != 1:
        out['exact_localization'] = None

    # 6. recommendation entitlement is orthogonal and failure-safe
    barred = (
        out['diagnostic_disposition'] in {'UNDERDETERMINED','NEW_TOPOLOGY_CANDIDATE','HOLD_REPRESENTATION','CLEAN'}
        or out['topology_label'] in {'CUMULATIVE_PATH','COMPENSATED_OR_MASKED','EQUIFINALITY'}
        or out['exact_localization'] is None
    )
    if (not barred and c.get('repair_target') and c.get('repair_mapping_exists',False) and c.get('verification_plan_exists',False)):
        out['repair_recommendation_entitled'] = True
        out['repair_target'] = c['repair_target']
        out['reason_codes'].append('REPAIR_RECOMMENDATION_ENTITLED')

    return finish_governance(c, out)

def finish_governance(c, out):
    # repair Human Gate vocabulary is manuscript-canonical
    gd = c.get('human_gate_decision','NONE')
    if out['repair_recommendation_entitled'] and gd == 'AUTHORIZE_SCOPE':
        out['repair_execution_authorized'] = True
        out['reason_codes'].append('HUMAN_GATE_AUTHORIZED_SCOPE')
    elif gd in {'REFUSE','NARROW_SCOPE','REQUEST_MORE_EVIDENCE'}:
        out['reason_codes'].append(f'HUMAN_GATE_{gd}')

    checks = c.get('re_audit_checks', None)
    if checks is not None:
        if not out['repair_execution_authorized']:
            out['closure_state'] = 'NOT_AUTHORIZED_FOR_CLOSURE'
            out['reason_codes'].append('NO_AUTHORIZED_EXECUTION')
        elif any(x == 'FAIL' for x in checks) or c.get('protected_invariants_ok') is False:
            out['closure_state'] = 'REOPENED_NOT_RESOLVED'
            out['reason_codes'].append('REAUDIT_FAIL')
        elif any(x == 'UNKNOWN' for x in checks) or c.get('protected_invariants_ok') is None:
            out['closure_state'] = 'HOLD'
            out['reason_codes'].append('REAUDIT_INCOMPLETE')
        elif all(x == 'PASS' for x in checks) and c.get('protected_invariants_ok') is True:
            out['closure_state'] = 'RESOLVED'
            out['reason_codes'].append('REAUDIT_ALL_PASS')

    # novel registry promotion is a separate state dimension
    if out['diagnostic_disposition'] == 'NEW_TOPOLOGY_CANDIDATE' or c.get('novel_candidate_recurrence',False):
        if c.get('lineage_independent') is False:
            out['registry_promotion_state'] = 'HOLD_PSEUDOREPLICATION'
            out['reason_codes'].append('LINEAGE_INDEPENDENCE_FAIL')
        elif c.get('lineage_independent') is True and c.get('promotion_gate_decision') == 'AUTHORIZE':
            out['registry_promotion_state'] = 'PROMOTED_BY_HUMAN_GATE'
            out['reason_codes'].append('PROMOTION_HUMAN_GATE_AUTHORIZED')
        elif c.get('promotion_gate_decision') == 'REFUSE':
            out['registry_promotion_state'] = 'REFUSED_PROMOTION'
        elif c.get('promotion_gate_decision') == 'DEFER':
            out['registry_promotion_state'] = 'DEFERRED_PROMOTION'
        else:
            out['registry_promotion_state'] = 'CANDIDATE_UNPROMOTED'

    h = deepcopy(out)
    h.pop('output_hash', None)
    out['output_hash'] = hashlib.sha256(json.dumps(h,sort_keys=True,separators=(',',':')).encode()).hexdigest()
    return out

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('input_json')
    ap.add_argument('-o','--output')
    a=ap.parse_args()
    raw=json.load(open(a.input_json,encoding='utf-8'))
    cases=raw if isinstance(raw,list) else raw['cases']
    res=[reconstruct(c) for c in cases]
    txt=json.dumps(res,indent=2,ensure_ascii=False)
    if a.output: open(a.output,'w',encoding='utf-8').write(txt)
    else: print(txt)
