from __future__ import annotations
from collections import deque

def tri_contract(values):
    """Aggregate declared hard-contract subpredicates: FAIL dominates; UNKNOWN blocks PASS."""
    vals=list(values)
    if any(v=='FAIL' for v in vals): return 'FAIL'
    if any(v=='UNKNOWN' for v in vals): return 'UNKNOWN'
    return 'PASS'

def direct_source_failure(contract_subpredicates):
    s=tri_contract(contract_subpredicates)
    if s=='FAIL': return True
    if s=='PASS': return False
    return None

def graph_reachable(edges, src, dst, graph_admissible=True):
    if not graph_admissible: return None
    adj={}
    for a,b in edges:
        adj.setdefault(a,[]).append(b)
    q=deque([src]); seen={src}
    while q:
        x=q.popleft()
        if x==dst: return True
        for y in adj.get(x,[]):
            if y not in seen:
                seen.add(y); q.append(y)
    return False

def eval_rule(value, operator, target):
    if value is None: return 'UNKNOWN'
    if operator == '<=': return 'PASS' if value <= target else 'FAIL'
    if operator == '<': return 'PASS' if value < target else 'FAIL'
    if operator == '>=': return 'PASS' if value >= target else 'FAIL'
    if operator == '>': return 'PASS' if value > target else 'FAIL'
    if operator == '==': return 'PASS' if value == target else 'FAIL'
    if operator == 'IN': return 'PASS' if value in target else 'FAIL'
    raise ValueError(operator)

def primitive_decomposition(relations, primitive_registry):
    if relations is None: return None
    return all(r in primitive_registry for r in relations)

def structural_residual(relations, primitive_registry):
    if relations is None: return None
    return sorted([r for r in relations if r not in primitive_registry])
