# WH JSS Executable Reconstruction V0.2

V0.2 synchronizes the reference serialization vocabulary with JSS Main/SI: repair authorization uses `AUTHORIZE_SCOPE`; registry promotion outputs `PROMOTED_BY_HUMAN_GATE`, `REFUSED_PROMOTION`, or `DEFERRED_PROMOTION`. No scientific decision rule or frozen P1-P3 empirical result is changed.

# WH JSS Executable Reconstruction V0.1

Purpose: demonstrate that the JSS decision contract can be implemented from the manuscript specification alone.

Boundary: this package was reconstructed without the unavailable archived historical WH implementation. It is therefore a specification-evaluability artifact, not evidence of bit-for-bit historical implementation equivalence.

Run:

```bash
python test_wh_jss_reference_adjudicator_v0_1.py
```

Expected current result:
- canonical edge cases: 20/20 PASS
- historical P3-A2 defect-class guards: 5/5 PASS
- precedence checks: 3/3 PASS
- generated abstract state-space/property regression: 9,216/9,216 PASS
