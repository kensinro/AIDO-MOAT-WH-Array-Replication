from wh_jss_input_normalizer_v0_1 import tri_contract,direct_source_failure,graph_reachable,eval_rule,primitive_decomposition,structural_residual

tests=[]
def T(name, got, exp): tests.append((name,got,exp,got==exp))
T('hard_all_pass',tri_contract(['PASS','PASS']),'PASS')
T('hard_fail_dominates',tri_contract(['PASS','FAIL','UNKNOWN']),'FAIL')
T('hard_unknown_blocks_pass',tri_contract(['PASS','UNKNOWN']),'UNKNOWN')
T('direct_source_true',direct_source_failure(['PASS','FAIL']),True)
T('direct_source_false',direct_source_failure(['PASS','PASS']),False)
T('direct_source_unknown',direct_source_failure(['PASS','UNKNOWN']),None)
edges=[('M1','M2'),('M2','M3')]
T('reach_yes',graph_reachable(edges,'M1','M3',True),True)
T('reach_no',graph_reachable(edges,'M3','M1',True),False)
T('reach_unknown_bad_graph',graph_reachable(edges,'M1','M3',False),None)
T('threshold_pass',eval_rule(0.08,'<=',0.10),'PASS')
T('threshold_fail',eval_rule(0.11,'<=',0.10),'FAIL')
T('threshold_unknown',eval_rule(None,'<=',0.10),'UNKNOWN')
T('categorical_pass',eval_rule('READY','IN',['READY','READY_WITH_WARNING']),'PASS')
T('categorical_fail',eval_rule('BLOCKED','IN',['READY','READY_WITH_WARNING']),'FAIL')
reg={'SERIAL','PARALLEL','MASKING'}
T('decomposition_complete',primitive_decomposition(['SERIAL','MASKING'],reg),True)
T('decomposition_incomplete',primitive_decomposition(['SERIAL','SYNERGY'],reg),False)
T('residual_none',structural_residual(['SERIAL','MASKING'],reg),[])
T('residual_present',structural_residual(['SERIAL','SYNERGY'],reg),['SYNERGY'])
for x in tests: print(('PASS' if x[3] else 'FAIL'),x[0],x[1],x[2])
print('SUMMARY',sum(x[3] for x in tests),len(tests))
assert all(x[3] for x in tests)
