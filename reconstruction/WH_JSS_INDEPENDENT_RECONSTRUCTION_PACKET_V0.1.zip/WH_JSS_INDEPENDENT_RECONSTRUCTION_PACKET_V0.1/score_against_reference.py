import json, sys, importlib.util, pathlib, hashlib
ROOT=pathlib.Path('/mnt/data/_wh_ir_v01')
refpath=pathlib.Path('/mnt/data/_wh_exec_unpack/WH_JSS_EXECUTABLE_RECONSTRUCTION_V0.1/wh_jss_reference_adjudicator_v0_1.py')
spec=importlib.util.spec_from_file_location('ref',refpath); ref=importlib.util.module_from_spec(spec); sys.modules['ref']=ref; spec.loader.exec_module(ref)
inputs=json.load(open(ROOT/'WH_JSS_BLIND_RECONSTRUCTION_INPUTS_V0.1.json',encoding='utf-8'))['cases']
preds=json.load(open(ROOT/'WH_JSS_BLIND_RECONSTRUCTION_PREDICTIONS_V0.1.json',encoding='utf-8'))
fields=['diagnostic_disposition','topology_label','known_space_compatible','resolution_state','compatible_topologies','unresolved_topologies','exact_localization','candidate_source_sets','inspection_state','repair_recommendation_entitled','repair_target','repair_execution_authorized','closure_state','registry_promotion_state']
rows=[]; mismatch=[]
for c,p in zip(inputs,preds):
    rc=dict(c)
    if rc.get('human_gate_decision')=='AUTHORIZE_SCOPE': rc['human_gate_decision']='AUTHORIZE'
    r=ref.trace_to_dict(ref.adjudicate(ref.CaseEvidence(**rc)))
    if r.get('registry_promotion_state')=='AUTHORIZED_PROSPECTIVE_VERSION': r['registry_promotion_state']='PROMOTED_BY_HUMAN_GATE'
    if r.get('registry_promotion_state')=='DEFER_PROMOTION': r['registry_promotion_state']='DEFERRED_PROMOTION'
    if r.get('registry_promotion_state')=='REFUSE_PROMOTION': r['registry_promotion_state']='REFUSED_PROMOTION'
    ok=True; diffs={}
    for f in fields:
        if p.get(f)!=r.get(f):
            ok=False; diffs[f]={'blind':p.get(f),'reference':r.get(f)}
    rows.append({'case_id':c['case_id'],'pass':ok,'differences':diffs,'blind_dd':p['diagnostic_disposition'],'ref_dd':r['diagnostic_disposition']})
    if not ok: mismatch.append(rows[-1])
report={'n':len(rows),'pass':sum(x['pass'] for x in rows),'fail':len(mismatch),'fields_compared':fields,'mismatches':mismatch}
json.dump(report,open(ROOT/'WH_JSS_BLIND_RECONSTRUCTION_SCORE_V0.1.json','w'),indent=2)
print(json.dumps(report,indent=2))
