import json, random, hashlib
from pathlib import Path
rnd=random.Random(24082026)

def base(i):
    return dict(case_id=f'BRX{i:03d}',integrity_contradiction=False,detection_status='ABNORMAL',
                topology_fields_complete=True,direct_failures=[],single_source_reachable=False,
                multi_source_reachable=False,minimal_source_sets=[],local_contracts_all_pass=False,
                path_or_global_invariant_fail=False,upstream_or_path_abnormality=False,
                endpoint_acceptable=False,opposing_influence=False,known_primitive_decomposable=False,
                structural_residual=False,inspection_eligible=False,repair_target=None,
                repair_mapping_exists=False,verification_plan_exists=False,human_gate_decision='NONE',
                re_audit_checks=None,protected_invariants_ok=None,novel_candidate_recurrence=False,
                lineage_independent=None,promotion_gate_decision='NONE')

cases=[]
def add(**kw):
    c=base(len(cases)+1); c.update(kw); cases.append(c)
# deterministic coverage cases
add(integrity_contradiction=True)
add(detection_status='UNKNOWN')
add(detection_status='CLEAN',topology_fields_complete=False)
add(topology_fields_complete=False,inspection_eligible=False)
add(topology_fields_complete=False,inspection_eligible=True)
add(direct_failures=['M2'],single_source_reachable=True,minimal_source_sets=[['M2']],repair_target='M2',repair_mapping_exists=True,verification_plan_exists=True)
add(direct_failures=['M2'],single_source_reachable=True,minimal_source_sets=[['M2']],repair_target='M2',repair_mapping_exists=True,verification_plan_exists=True,human_gate_decision='AUTHORIZE_SCOPE',re_audit_checks=['PASS','PASS'],protected_invariants_ok=True)
add(direct_failures=['M2'],single_source_reachable=True,minimal_source_sets=[['M2']],repair_target='M2',repair_mapping_exists=True,verification_plan_exists=True,human_gate_decision='AUTHORIZE_SCOPE',re_audit_checks=['PASS','FAIL'],protected_invariants_ok=True)
add(direct_failures=['M2'],single_source_reachable=True,minimal_source_sets=[['M2']],repair_target='M2',repair_mapping_exists=True,verification_plan_exists=True,human_gate_decision='AUTHORIZE_SCOPE',re_audit_checks=['PASS','UNKNOWN'],protected_invariants_ok=True)
add(direct_failures=['M2','M5'],multi_source_reachable=True,minimal_source_sets=[['M2','M5']])
add(direct_failures=[],minimal_source_sets=[['M2'],['M5']],inspection_eligible=True)
add(direct_failures=[],minimal_source_sets=[['M2'],['M5']],inspection_eligible=False)
add(direct_failures=[],local_contracts_all_pass=True,path_or_global_invariant_fail=True,minimal_source_sets=[['PATH_CUMULATIVE']],repair_target='M2',repair_mapping_exists=True,verification_plan_exists=True)
add(direct_failures=['M2'],single_source_reachable=False,minimal_source_sets=[['M2']],upstream_or_path_abnormality=True,endpoint_acceptable=True,opposing_influence=True)
add(direct_failures=['M2'],single_source_reachable=True,minimal_source_sets=[['M2']],upstream_or_path_abnormality=True,endpoint_acceptable=True,opposing_influence=True,inspection_eligible=True)
add(direct_failures=[],minimal_source_sets=[],known_primitive_decomposable=True)
add(direct_failures=[],minimal_source_sets=[],structural_residual=True,lineage_independent=None)
add(direct_failures=[],minimal_source_sets=[],structural_residual=True,novel_candidate_recurrence=True,lineage_independent=False,promotion_gate_decision='AUTHORIZE')
add(direct_failures=[],minimal_source_sets=[],structural_residual=True,novel_candidate_recurrence=True,lineage_independent=True,promotion_gate_decision='AUTHORIZE')
add(direct_failures=[],minimal_source_sets=[],structural_residual=False)
# random broad coverage; these are abstract normalized predicate vectors, not performance cases
for _ in range(44):
    c=base(len(cases)+1)
    c['integrity_contradiction']=rnd.random()<0.05
    c['detection_status']=rnd.choices(['ABNORMAL','CLEAN','UNKNOWN'],[0.78,0.12,0.10])[0]
    c['topology_fields_complete']=rnd.random()<0.82
    ndf=rnd.choice([0,0,0,1,1,2,2,None])
    c['direct_failures']=None if ndf is None else [f'M{x+1}' for x in range(ndf)]
    c['single_source_reachable']=rnd.choice([True,False,None])
    c['multi_source_reachable']=rnd.choice([True,False,None])
    nsets=rnd.choice([0,1,1,2,2,None])
    c['minimal_source_sets']=None if nsets is None else [[f'M{j+1+i}'] for i in range(nsets) for j in [0]]
    c['local_contracts_all_pass']=rnd.choice([True,False,None])
    c['path_or_global_invariant_fail']=rnd.choice([True,False,None])
    c['upstream_or_path_abnormality']=rnd.choice([True,False,None])
    c['endpoint_acceptable']=rnd.choice([True,False,None])
    c['opposing_influence']=rnd.choice([True,False,None])
    c['known_primitive_decomposable']=rnd.random()<0.18
    c['structural_residual']=rnd.random()<0.20
    c['inspection_eligible']=rnd.random()<0.35
    if rnd.random()<0.35:
        c['repair_target']='M1'; c['repair_mapping_exists']=rnd.random()<0.8; c['verification_plan_exists']=rnd.random()<0.8
    c['human_gate_decision']=rnd.choice(['NONE','NONE','AUTHORIZE_SCOPE','REFUSE','NARROW_SCOPE','REQUEST_MORE_EVIDENCE'])
    if rnd.random()<0.25:
        c['re_audit_checks']=rnd.choice([['PASS','PASS'],['PASS','FAIL'],['PASS','UNKNOWN']]); c['protected_invariants_ok']=rnd.choice([True,False,None])
    c['novel_candidate_recurrence']=rnd.random()<0.12
    c['lineage_independent']=rnd.choice([True,False,None])
    c['promotion_gate_decision']=rnd.choice(['NONE','AUTHORIZE','REFUSE','DEFER'])
    cases.append(c)

out={'contract':'JSS-V0.5.4-normalized-input','seed':24082026,'cases':cases}
Path('/mnt/data/_wh_ir_v01/WH_JSS_BLIND_RECONSTRUCTION_INPUTS_V0.1.json').write_text(json.dumps(out,indent=2),encoding='utf-8')
print(len(cases))
print(hashlib.sha256(Path('/mnt/data/_wh_ir_v01/WH_JSS_BLIND_RECONSTRUCTION_INPUTS_V0.1.json').read_bytes()).hexdigest())
