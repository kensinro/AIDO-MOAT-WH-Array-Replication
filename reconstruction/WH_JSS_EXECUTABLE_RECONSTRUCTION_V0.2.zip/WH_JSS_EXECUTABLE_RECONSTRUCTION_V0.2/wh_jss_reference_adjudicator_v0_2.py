from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Optional, List, Dict, Any, Tuple
import hashlib, json

class Tri(str, Enum):
    TRUE = 'TRUE'
    FALSE = 'FALSE'
    UNKNOWN = 'UNKNOWN'

class Compatibility(str, Enum):
    COMPATIBLE = 'COMPATIBLE'
    INCOMPATIBLE = 'INCOMPATIBLE'
    UNRESOLVED = 'UNRESOLVED'

@dataclass
class CaseEvidence:
    case_id: str
    integrity_contradiction: bool = False
    detection_status: str = 'UNKNOWN'  # ABNORMAL | CLEAN | UNKNOWN
    topology_fields_complete: bool = False
    direct_failures: Optional[List[str]] = None
    single_source_reachable: Optional[bool] = None
    multi_source_reachable: Optional[bool] = None
    minimal_source_sets: Optional[List[List[str]]] = None
    local_contracts_all_pass: Optional[bool] = None
    path_or_global_invariant_fail: Optional[bool] = None
    upstream_or_path_abnormality: Optional[bool] = None
    endpoint_acceptable: Optional[bool] = None
    opposing_influence: Optional[bool] = None
    known_primitive_decomposable: bool = False
    structural_residual: bool = False
    inspection_eligible: bool = False
    repair_target: Optional[str] = None
    repair_mapping_exists: bool = False
    verification_plan_exists: bool = False
    human_gate_decision: str = 'NONE'  # NONE | AUTHORIZE_SCOPE | REFUSE | NARROW_SCOPE | REQUEST_MORE_EVIDENCE
    re_audit_checks: Optional[List[str]] = None  # PASS | FAIL | UNKNOWN
    protected_invariants_ok: Optional[bool] = None
    novel_candidate_recurrence: bool = False
    lineage_independent: Optional[bool] = None
    promotion_gate_decision: str = 'NONE'  # NONE | AUTHORIZE | REFUSE | DEFER

@dataclass
class DecisionTrace:
    case_id: str
    contract_version: str = 'JSS-REF-V0.2'
    diagnostic_disposition: str = 'UNDERDETERMINED'
    topology_label: Optional[str] = None
    known_space_compatible: bool = False
    resolution_state: str = 'UNDERDETERMINED'
    compatible_topologies: List[str] = field(default_factory=list)
    unresolved_topologies: List[str] = field(default_factory=list)
    exact_localization: Optional[List[str]] = None
    candidate_source_sets: List[List[str]] = field(default_factory=list)
    inspection_state: str = 'NOT_REQUESTED'
    repair_recommendation_entitled: bool = False
    repair_target: Optional[str] = None
    repair_execution_authorized: bool = False
    closure_state: str = 'NOT_APPLICABLE'
    registry_promotion_state: str = 'NOT_APPLICABLE'
    reason_codes: List[str] = field(default_factory=list)
    output_hash: str = ''

    def finalize(self):
        payload = asdict(self).copy()
        payload['output_hash'] = ''
        self.output_hash = hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()).hexdigest()
        return self


def _tri_bool(v: Optional[bool]) -> Tri:
    if v is True: return Tri.TRUE
    if v is False: return Tri.FALSE
    return Tri.UNKNOWN


def _compat(required: List[Tri], disqualifiers: List[Tri]) -> Compatibility:
    if any(v == Tri.FALSE for v in required) or any(v == Tri.TRUE for v in disqualifiers):
        return Compatibility.INCOMPATIBLE
    if any(v == Tri.UNKNOWN for v in required) or any(v == Tri.UNKNOWN for v in disqualifiers):
        return Compatibility.UNRESOLVED
    return Compatibility.COMPATIBLE


def evaluate_topologies(e: CaseEvidence) -> Dict[str, Compatibility]:
    direct = e.direct_failures
    n_direct = None if direct is None else len(direct)
    source_sets = e.minimal_source_sets
    n_sets = None if source_sets is None else len(source_sets)

    req_single = [
        Tri.UNKNOWN if n_direct is None else (Tri.TRUE if n_direct == 1 else Tri.FALSE),
        _tri_bool(e.single_source_reachable),
    ]
    req_multi = [
        Tri.UNKNOWN if n_direct is None else (Tri.TRUE if n_direct >= 2 else Tri.FALSE),
        _tri_bool(e.multi_source_reachable),
    ]
    req_equif = [Tri.UNKNOWN if n_sets is None else (Tri.TRUE if n_sets >= 2 else Tri.FALSE)]
    req_cum = [
        _tri_bool(e.local_contracts_all_pass),
        _tri_bool(e.path_or_global_invariant_fail),
        Tri.UNKNOWN if n_direct is None else (Tri.TRUE if n_direct == 0 else Tri.FALSE),
    ]
    req_mask = [
        _tri_bool(e.upstream_or_path_abnormality),
        _tri_bool(e.endpoint_acceptable),
        _tri_bool(e.opposing_influence),
    ]
    return {
        'SINGLE_SOURCE_LOCAL': _compat(req_single, []),
        'MULTI_SOURCE': _compat(req_multi, []),
        'EQUIFINALITY': _compat(req_equif, []),
        'CUMULATIVE_PATH': _compat(req_cum, []),
        'COMPENSATED_OR_MASKED': _compat(req_mask, []),
    }


def adjudicate(e: CaseEvidence) -> DecisionTrace:
    t = DecisionTrace(case_id=e.case_id)

    # Integrity precedence.
    if e.integrity_contradiction:
        t.diagnostic_disposition = 'HOLD_REPRESENTATION'
        t.resolution_state = 'HOLD_REPRESENTATION'
        t.reason_codes.append('INTEGRITY_PRECEDENCE')
        return _finish_governance(e, t)

    # Detection layer.
    if e.detection_status == 'UNKNOWN':
        t.diagnostic_disposition = 'UNDERDETERMINED'
        t.resolution_state = 'UNDERDETERMINED'
        t.reason_codes.append('DETECTION_INSUFFICIENT')
        return _finish_governance(e, t)
    if e.detection_status == 'CLEAN':
        t.diagnostic_disposition = 'CLEAN'
        t.resolution_state = 'CLEAN'
        t.reason_codes.append('CLEAN_PREDICATES_SATISFIED')
        return _finish_governance(e, t)

    # Structural descriptor / source-set retention.
    t.candidate_source_sets = e.minimal_source_sets or []
    if e.minimal_source_sets is not None and len(e.minimal_source_sets) == 1:
        t.exact_localization = list(e.minimal_source_sets[0])

    # Topology sufficiency. If an eligible inspection can resolve a required UNKNOWN,
    # retain UNDERDETERMINED diagnosis but expose a separate targeted-inspection state.
    if not e.topology_fields_complete:
        t.diagnostic_disposition = 'UNDERDETERMINED'
        if e.inspection_eligible:
            t.resolution_state = 'HOLD_TARGETED_INSPECTION'
            t.inspection_state = 'REQUEST_ELIGIBLE'
            t.reason_codes.append('TOPOLOGY_INSUFFICIENT_INSPECTION_AVAILABLE')
        else:
            t.resolution_state = 'UNDERDETERMINED'
            t.reason_codes.append('TOPOLOGY_INSUFFICIENT')
        return _finish_governance(e, t)

    comp = evaluate_topologies(e)
    t.compatible_topologies = sorted([k for k,v in comp.items() if v == Compatibility.COMPATIBLE])
    t.unresolved_topologies = sorted([k for k,v in comp.items() if v == Compatibility.UNRESOLVED])
    t.known_space_compatible = bool(t.compatible_topologies)

    # Unique known class.
    if len(t.compatible_topologies) == 1:
        topo = t.compatible_topologies[0]
        t.diagnostic_disposition = f'KNOWN_CLASS({topo})'
        t.topology_label = topo
        if topo == 'EQUIFINALITY' and len(t.candidate_source_sets) >= 2:
            if e.inspection_eligible:
                t.resolution_state = 'HOLD_TARGETED_INSPECTION'
                t.inspection_state = 'REQUEST_ELIGIBLE'
                t.reason_codes.append('TOPOLOGY_KNOWN_SOURCE_UNRESOLVED')
            else:
                t.resolution_state = 'RESOLVED_TOPOLOGY_SOURCE_UNRESOLVED'
                t.reason_codes.append('EQUIFINALITY_NO_EXACT_SOURCE')
        else:
            t.resolution_state = 'RESOLVED_DIAGNOSTIC'
            t.reason_codes.append('UNIQUE_KNOWN_TOPOLOGY')
    # Known-primitive combination is an orthogonal resolution for cases not entitled to one unique class.
    elif e.known_primitive_decomposable:
        t.diagnostic_disposition = 'KNOWN_PRIMITIVE_COMBINATION'
        t.resolution_state = 'RESOLVED_DIAGNOSTIC'
        t.reason_codes.append('KNOWN_PRIMITIVE_DECOMPOSITION')
    elif len(t.compatible_topologies) > 1:
        t.diagnostic_disposition = 'UNDERDETERMINED'
        if e.inspection_eligible:
            t.resolution_state = 'HOLD_TARGETED_INSPECTION'
            t.inspection_state = 'REQUEST_ELIGIBLE'
            t.reason_codes.append('MULTIPLE_COMPATIBLE_TOPOLOGIES')
        else:
            t.resolution_state = 'UNDERDETERMINED'
            t.reason_codes.append('MULTIPLE_COMPATIBLE_NO_DISCRIMINATOR')
    elif len(t.compatible_topologies) == 0 and e.structural_residual:
        t.diagnostic_disposition = 'NEW_TOPOLOGY_CANDIDATE'
        t.resolution_state = 'CANDIDATE_ONLY'
        t.reason_codes.append('NO_KNOWN_COMPATIBLE_WITH_STRUCTURAL_RESIDUAL')
    else:
        t.diagnostic_disposition = 'UNDERDETERMINED'
        t.resolution_state = 'UNDERDETERMINED'
        t.reason_codes.append('NO_UNIQUE_ENTITLED_TOPOLOGY')

    # Exact localization is only meaningful when a single minimal source set remains.
    if e.minimal_source_sets is None or len(e.minimal_source_sets) != 1:
        t.exact_localization = None

    # Repair recommendation entitlement is orthogonal to diagnostic state.
    barred = (
        t.diagnostic_disposition in {'UNDERDETERMINED','NEW_TOPOLOGY_CANDIDATE','HOLD_REPRESENTATION','CLEAN'}
        or t.topology_label in {'CUMULATIVE_PATH','COMPENSATED_OR_MASKED','EQUIFINALITY'}
        or t.exact_localization is None
    )
    if (not barred and e.repair_target and e.repair_mapping_exists and e.verification_plan_exists):
        t.repair_recommendation_entitled = True
        t.repair_target = e.repair_target
        t.reason_codes.append('REPAIR_RECOMMENDATION_ENTITLED')

    return _finish_governance(e, t)


def _finish_governance(e: CaseEvidence, t: DecisionTrace) -> DecisionTrace:
    # Repair execution authorization is a separate Human-Gate object.
    if t.repair_recommendation_entitled and e.human_gate_decision == 'AUTHORIZE_SCOPE':
        t.repair_execution_authorized = True
        t.reason_codes.append('HUMAN_GATE_AUTHORIZED_SCOPE')
    elif e.human_gate_decision in {'REFUSE','NARROW_SCOPE','REQUEST_MORE_EVIDENCE'}:
        t.repair_execution_authorized = False
        t.reason_codes.append(f'HUMAN_GATE_{e.human_gate_decision}')

    # Re-audit closure. A resolved closure requires prior authorized execution.
    if e.re_audit_checks is not None:
        if not t.repair_execution_authorized:
            t.closure_state = 'NOT_AUTHORIZED_FOR_CLOSURE'
            t.reason_codes.append('NO_AUTHORIZED_EXECUTION')
        elif any(x == 'FAIL' for x in e.re_audit_checks) or e.protected_invariants_ok is False:
            t.closure_state = 'REOPENED_NOT_RESOLVED'
            t.reason_codes.append('REAUDIT_FAIL')
        elif any(x == 'UNKNOWN' for x in e.re_audit_checks) or e.protected_invariants_ok is None:
            t.closure_state = 'HOLD'
            t.reason_codes.append('REAUDIT_INCOMPLETE')
        elif all(x == 'PASS' for x in e.re_audit_checks) and e.protected_invariants_ok is True:
            t.closure_state = 'RESOLVED'
            t.reason_codes.append('REAUDIT_ALL_PASS')

    # Registry promotion state for novel candidates is separate from diagnosis.
    if t.diagnostic_disposition == 'NEW_TOPOLOGY_CANDIDATE' or e.novel_candidate_recurrence:
        if e.lineage_independent is False:
            t.registry_promotion_state = 'HOLD_PSEUDOREPLICATION'
            t.reason_codes.append('LINEAGE_INDEPENDENCE_FAIL')
        elif e.lineage_independent is True and e.promotion_gate_decision == 'AUTHORIZE':
            t.registry_promotion_state = 'PROMOTED_BY_HUMAN_GATE'
            t.reason_codes.append('PROMOTION_HUMAN_GATE_AUTHORIZED_SCOPE')
        elif e.promotion_gate_decision in {'REFUSE','DEFER'}:
            t.registry_promotion_state = 'REFUSED_PROMOTION' if e.promotion_gate_decision == 'REFUSE' else 'DEFERRED_PROMOTION'
        else:
            t.registry_promotion_state = 'CANDIDATE_UNPROMOTED'

    return t.finalize()


def trace_to_dict(trace: DecisionTrace) -> Dict[str, Any]:
    return asdict(trace)

if __name__ == '__main__':
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument('input_json')
    ap.add_argument('-o','--output')
    args = ap.parse_args()
    raw = json.load(open(args.input_json, encoding='utf-8'))
    cases = raw if isinstance(raw, list) else raw['cases']
    out = [trace_to_dict(adjudicate(CaseEvidence(**c))) for c in cases]
    txt = json.dumps(out, indent=2, ensure_ascii=False)
    if args.output:
        open(args.output,'w',encoding='utf-8').write(txt)
    else:
        print(txt)
