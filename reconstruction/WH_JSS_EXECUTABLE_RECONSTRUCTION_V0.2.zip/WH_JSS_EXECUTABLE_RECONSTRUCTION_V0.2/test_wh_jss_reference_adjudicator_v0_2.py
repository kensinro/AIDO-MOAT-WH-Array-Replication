import json, itertools, csv, hashlib, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from wh_jss_reference_adjudicator_v0_2 import CaseEvidence, adjudicate, evaluate_topologies

fixture_path=str(HERE/'WH_JSS_RECONSTRUCTION_FIXTURES_V0.1.json')
cases=json.load(open(fixture_path))['cases']

expected={
'E01': {'diagnostic_disposition':'HOLD_REPRESENTATION'},
'E02': {'diagnostic_disposition':'UNDERDETERMINED','resolution_state':'UNDERDETERMINED'},
'E03': {'diagnostic_disposition':'CLEAN'},
'E04': {'diagnostic_disposition':'KNOWN_CLASS(SINGLE_SOURCE_LOCAL)','exact_localization':['M02']},
'E05': {'diagnostic_disposition':'UNDERDETERMINED','resolution_state':'HOLD_TARGETED_INSPECTION'},
'E06': {'diagnostic_disposition':'UNDERDETERMINED','resolution_state':'UNDERDETERMINED'},
'E07': {'diagnostic_disposition':'NEW_TOPOLOGY_CANDIDATE','registry_promotion_state':'CANDIDATE_UNPROMOTED'},
'E08': {'diagnostic_disposition':'UNDERDETERMINED'},
'E09': {'diagnostic_disposition':'KNOWN_PRIMITIVE_COMBINATION'},
'E10': {'diagnostic_disposition':'CLEAN'},
'E11': {'diagnostic_disposition':'KNOWN_CLASS(EQUIFINALITY)','resolution_state':'HOLD_TARGETED_INSPECTION','exact_localization':None},
'E12': {'diagnostic_disposition':'KNOWN_CLASS(SINGLE_SOURCE_LOCAL)','exact_localization':['M01']},
'E13': {'diagnostic_disposition':'KNOWN_CLASS(CUMULATIVE_PATH)','repair_recommendation_entitled':False},
'E14': {'diagnostic_disposition':'KNOWN_CLASS(COMPENSATED_OR_MASKED)','repair_recommendation_entitled':False},
'E15': {'repair_recommendation_entitled':True,'repair_execution_authorized':False},
'E16': {'repair_recommendation_entitled':True,'repair_execution_authorized':False},
'E17': {'repair_execution_authorized':True,'closure_state':'RESOLVED'},
'E18': {'closure_state':'HOLD'},
'E19': {'closure_state':'REOPENED_NOT_RESOLVED'},
'E20': {'diagnostic_disposition':'NEW_TOPOLOGY_CANDIDATE','registry_promotion_state':'HOLD_PSEUDOREPLICATION'},
}

rows=[]
failed=[]
for raw in cases:
    tr=adjudicate(CaseEvidence(**raw))
    checks=[]
    ok=True
    for k,v in expected[raw['case_id']].items():
        got=getattr(tr,k)
        one=(got==v)
        checks.append(f'{k}={got!r} expected {v!r}: {"PASS" if one else "FAIL"}')
        ok &= one
    rows.append((raw['case_id'], ok, tr, '; '.join(checks)))
    if not ok: failed.append(raw['case_id'])

# Historical P3-A2 conformance defect guards (C1-C4)
historical=[]
# C1 cumulative path object not constituent module IDs
tr=adjudicate(CaseEvidence(**next(c for c in cases if c['case_id']=='E13')))
historical.append(('A2-C1', tr.topology_label=='CUMULATIVE_PATH' and tr.exact_localization==['PATH_CUMULATIVE']))
# C2 decisive inspection may re-adjudicate to single source (E12)
tr=adjudicate(CaseEvidence(**next(c for c in cases if c['case_id']=='E12')))
historical.append(('A2-C2', tr.topology_label=='SINGLE_SOURCE_LOCAL' and tr.exact_localization==['M01']))
# C3 cumulative/compensated no direct repair target
for cid in ['E13','E14']:
    tr=adjudicate(CaseEvidence(**next(c for c in cases if c['case_id']==cid)))
    historical.append((f'A2-C3-{cid}', not tr.repair_recommendation_entitled))
# C4 novel remains candidate-only, no repair
tr=adjudicate(CaseEvidence(**next(c for c in cases if c['case_id']=='E07')))
historical.append(('A2-C4', tr.diagnostic_disposition=='NEW_TOPOLOGY_CANDIDATE' and not tr.repair_recommendation_entitled and tr.resolution_state=='CANDIDATE_ONLY'))

# Generated state-space/property regression over 12,288 abstract abnormal combinations.
prop_fail=[]
count=0
for n_direct, single_r, multi_r, n_sets, local_pass, global_fail, upstream, endpoint_ok, oppose, known_decomp, residual, inspect in itertools.product(
    [0,1,2], [False,True], [False,True], [0,1,2], [False,True], [False,True], [False,True], [False,True], [False,True], [False,True], [False,True], [False,True]):
    count += 1
    direct=[f'M{i}' for i in range(n_direct)]
    sets=[] if n_sets==0 else [[f'S{i}'] for i in range(n_sets)]
    e=CaseEvidence(case_id=f'G{count}', detection_status='ABNORMAL', topology_fields_complete=True,
        direct_failures=direct, single_source_reachable=single_r, multi_source_reachable=multi_r,
        minimal_source_sets=sets, local_contracts_all_pass=local_pass, path_or_global_invariant_fail=global_fail,
        upstream_or_path_abnormality=upstream, endpoint_acceptable=endpoint_ok, opposing_influence=oppose,
        known_primitive_decomposable=known_decomp, structural_residual=residual, inspection_eligible=inspect)
    tr=adjudicate(e)
    # Invariants
    if not tr.diagnostic_disposition:
        prop_fail.append((count,'no diagnostic disposition'))
    if tr.repair_execution_authorized and not tr.repair_recommendation_entitled:
        prop_fail.append((count,'authorization without recommendation entitlement'))
    if tr.closure_state=='RESOLVED' and not tr.repair_execution_authorized:
        prop_fail.append((count,'closure without authorization'))
    if tr.diagnostic_disposition=='NEW_TOPOLOGY_CANDIDATE':
        if tr.compatible_topologies or not residual:
            prop_fail.append((count,'invalid novelty condition'))
    if len(tr.compatible_topologies)>1 and tr.diagnostic_disposition.startswith('KNOWN_CLASS('):
        prop_fail.append((count,'forced class with multiple compatible topologies'))
    if tr.topology_label in {'CUMULATIVE_PATH','COMPENSATED_OR_MASKED','EQUIFINALITY'} and tr.repair_recommendation_entitled:
        prop_fail.append((count,'unsupported direct repair for higher-order/unresolved topology'))

# Special precedence checks
precedence=[]
p=CaseEvidence(case_id='P1', integrity_contradiction=True, detection_status='CLEAN')
precedence.append(('integrity_over_clean', adjudicate(p).diagnostic_disposition=='HOLD_REPRESENTATION'))
p=CaseEvidence(case_id='P2', detection_status='UNKNOWN', topology_fields_complete=True, direct_failures=['M1'], single_source_reachable=True)
precedence.append(('unknown_detection_blocks_topology', adjudicate(p).diagnostic_disposition=='UNDERDETERMINED'))
p=CaseEvidence(case_id='P3', detection_status='ABNORMAL', topology_fields_complete=False, inspection_eligible=True)
precedence.append(('insufficient_topology_can_request_inspection', adjudicate(p).resolution_state=='HOLD_TARGETED_INSPECTION'))

all_ok=(not failed and all(v for _,v in historical) and not prop_fail and all(v for _,v in precedence))

# Write outputs
with open('/mnt/data/WH_JSS_RECONSTRUCTION_EXECUTED_EDGE_MATRIX_V0.2.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f)
    w.writerow(['case_id','pass','diagnostic_disposition','topology_label','resolution_state','compatible_topologies','exact_localization','inspection_state','repair_recommendation_entitled','repair_execution_authorized','closure_state','registry_promotion_state','output_hash','check_detail'])
    for cid,ok,tr,detail in rows:
        w.writerow([cid,ok,tr.diagnostic_disposition,tr.topology_label,tr.resolution_state,'|'.join(tr.compatible_topologies),json.dumps(tr.exact_localization),tr.inspection_state,tr.repair_recommendation_entitled,tr.repair_execution_authorized,tr.closure_state,tr.registry_promotion_state,tr.output_hash,detail])

summary={
 'reconstruction_type':'specification-only clean-room executable reconstruction',
 'archived_historical_code_consulted':False,
 'canonical_cases':{'passed':sum(ok for _,ok,_,_ in rows),'total':len(rows),'failed_ids':failed},
 'historical_conformance_guards':{'passed':sum(v for _,v in historical),'total':len(historical),'details':historical},
 'generated_property_cases':{'passed':count-len(prop_fail),'total':count,'failures':prop_fail[:50]},
 'precedence_checks':{'passed':sum(v for _,v in precedence),'total':len(precedence),'details':precedence},
 'overall_pass':all_ok,
 'important_boundary':'This demonstrates that the published V0.5.1/V0.5.2 decision contract can be implemented consistently. It does NOT establish equivalence to the unavailable historical frozen WH implementation.'
}
json.dump(summary, open('/mnt/data/WH_JSS_SPECIFICATION_RECONSTRUCTION_AUDIT_V0.1.json','w'), indent=2)

with open('/mnt/data/WH_JSS_SPECIFICATION_RECONSTRUCTION_AUDIT_V0.1.md','w',encoding='utf-8') as f:
    f.write('# WH JSS Specification-Only Executable Reconstruction Audit V0.1\n\n')
    f.write('**Basis:** JSS manuscript decision contract only; archived historical WH code was not available or consulted.\n\n')
    f.write(f'**Canonical edge cases:** {summary["canonical_cases"]["passed"]}/{summary["canonical_cases"]["total"]} PASS.\n\n')
    f.write(f'**Historical P3-A2 conformance guards:** {summary["historical_conformance_guards"]["passed"]}/{summary["historical_conformance_guards"]["total"]} PASS.\n\n')
    f.write(f'**Generated abstract state-space/property regression:** {summary["generated_property_cases"]["passed"]}/{summary["generated_property_cases"]["total"]} PASS.\n\n')
    f.write(f'**Precedence checks:** {summary["precedence_checks"]["passed"]}/{summary["precedence_checks"]["total"]} PASS.\n\n')
    f.write('## Key reconstruction finding\n\n')
    f.write('Executable reconstruction exposed an ambiguity in V0.5.1: topology identity, source-resolution state, repair recommendation entitlement, Human authorization, repair closure, and registry-promotion state are not one mutually exclusive state variable. V0.5.2 should serialize them as orthogonal decision-trace fields. In particular, EQUIFINALITY can be a known topology while source localization remains HOLD_TARGETED_INSPECTION.\n\n')
    f.write('A second ambiguity was exposed in Algorithm 1 step 7: topology insufficiency could previously return UNDERDETERMINED before an eligible inspection was considered, despite Section 2.5 allowing inspection to resolve UNKNOWN predicates. The executable reference resolves this by preserving diagnostic UNDERDETERMINED while setting resolution_state=HOLD_TARGETED_INSPECTION when an eligible discriminator exists.\n\n')
    f.write('## Boundary\n\n')
    f.write(summary['important_boundary']+'\n')

print(json.dumps(summary, indent=2))
if not all_ok:
    raise SystemExit(1)
